import React from "react";
import "./Shop.css";
import ShopSidebar from "../ShopSidebar/ShopSidebar";

function Shop() {
  return (
    <>
      <div className="container">
        <ShopSidebar />
      </div>
    </>
  );
}

export default Shop;
