const CheckoutPage = () => {
  return <div>CheckoutPage</div>;
};
export default CheckoutPage;
