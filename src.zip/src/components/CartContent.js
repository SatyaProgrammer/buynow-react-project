const CartContent = () => {
  return <div>CartContent</div>;
};
export default CartContent;
