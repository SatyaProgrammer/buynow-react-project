const CarContent = () => {
  return <div>CarContent</div>;
};
export default CarContent;
