const StripeCheckout = () => {
  return <div>StripeCheckout</div>;
};
export default StripeCheckout;
